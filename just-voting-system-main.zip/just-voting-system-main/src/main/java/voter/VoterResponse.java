package com.just.votingsystem.dto.voter;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class VoterResponse {

    private Long id;
    private String studentId;
    private String fullName;
    private String department;
    private String faculty;
    private boolean accountActivated;
    private boolean hasVoted;
    private Long userId;
}