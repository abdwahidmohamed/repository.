package com.just.votingsystem.repository;

import com.just.votingsystem.entity.Election;
import com.just.votingsystem.enums.ElectionStatus;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ElectionRepository extends JpaRepository<Election, Long> {

    List<Election> findByStatus(ElectionStatus status);
}