package com.just.votingsystem.entity;

import com.just.votingsystem.enums.Role;
import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDateTime;
@Entity
@Table(name = "users")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, unique = true)
    private String email;

    @Column(nullable = false)
    private String password;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private Role role; //    Waxay noqon kartaa oo keliya:adim ama user

    @Column(nullable = false, updatable = false)
    private LocalDateTime createdAt;

    @OneToOne(mappedBy = "user")
    private Voter voter;


    @PrePersist
    public void prePersist() {
        createdAt = LocalDateTime.now(); // Waxay kaydisaa waqtiga user-ka la sameeyay.
    }
}