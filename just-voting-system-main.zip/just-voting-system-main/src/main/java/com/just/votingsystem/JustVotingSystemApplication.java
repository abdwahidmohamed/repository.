package com.just.votingsystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JustVotingSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(JustVotingSystemApplication.class, args);
	}

}
