package com.just.votingsystem.controller;

import com.just.votingsystem.dto.voter.VoterRequest;
import com.just.votingsystem.dto.voter.VoterResponse;
import com.just.votingsystem.service.VoterService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/voters")
@RequiredArgsConstructor
public class VoterController {

    private final VoterService voterService;

    // CREATE
    @PostMapping
    public VoterResponse createVoter(@Valid @RequestBody VoterRequest request) {
        return voterService.createVoter(request);
    }

    // READ ALL
    @GetMapping
    public List<VoterResponse> getAllVoters() {
        return voterService.getAllVoters();
    }

    // READ BY ID
    @GetMapping("/{id}")
    public VoterResponse getVoterById(@PathVariable Long id) {
        return voterService.getVoterById(id);
    }

    // UPDATE
    @PutMapping("/{id}")
    public VoterResponse updateVoter(@PathVariable Long id,
                                     @Valid @RequestBody VoterRequest request) {
        return voterService.updateVoter(id, request);
    }

    // DELETE
    @DeleteMapping("/{id}")
    public String deleteVoter(@PathVariable Long id) {
        voterService.deleteVoter(id);
        return "Voter deleted successfully";
    }
}