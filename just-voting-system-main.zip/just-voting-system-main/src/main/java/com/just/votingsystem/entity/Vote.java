package com.just.votingsystem.entity;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDateTime;

@Entity
@Table(
        // Hal voter ma codeyn karo laba jeer isla election-ka.
        name = "votes",
        uniqueConstraints = {
                @UniqueConstraint(columnNames = {"voter_id", "election_id"})
        }
)
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Vote {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "voter_id", nullable = false)
    private Voter voter;

    @ManyToOne // Hal Candidate waxaa u codeyn kara dad badan.
    @JoinColumn(name = "candidate_id", nullable = false)
    private Candidate candidate;

    @ManyToOne // Hal Election waxaa ku jiri doona kumannaan cod.
    @JoinColumn(name = "election_id", nullable = false)
    private Election election;

    @Column(nullable = false, updatable = false)
    private LocalDateTime votedAt;

    @PrePersist
    public void prePersist() {
        votedAt = LocalDateTime.now();
    }
}