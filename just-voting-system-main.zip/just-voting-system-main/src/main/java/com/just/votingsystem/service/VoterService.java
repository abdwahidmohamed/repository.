package com.just.votingsystem.service;

import com.just.votingsystem.dto.voter.VoterRequest;
import com.just.votingsystem.dto.voter.VoterResponse;
import com.just.votingsystem.entity.User;
import com.just.votingsystem.entity.Voter;
import com.just.votingsystem.repository.UserRepository;
import com.just.votingsystem.repository.VoterRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class VoterService {

    private final VoterRepository voterRepository;
    private final UserRepository userRepository;

    // CREATE
    public VoterResponse createVoter(VoterRequest request) {

        if (voterRepository.existsByStudentId(request.getStudentId())) {
            throw new RuntimeException("Student ID already exists.");
        }

        User user = userRepository.findById(request.getUserId())
                .orElseThrow(() -> new RuntimeException("User not found"));

        Voter voter = Voter.builder()
                .studentId(request.getStudentId())
                .fullName(request.getFullName())
                .department(request.getDepartment())
                .faculty(request.getFaculty())
                .accountActivated(false)
                .hasVoted(false)
                .user(user)
                .build();

        Voter saved = voterRepository.save(voter);

        return mapToResponse(saved);
    }

    // READ ALL
    public List<VoterResponse> getAllVoters() {
        return voterRepository.findAll()
                .stream()
                .map(this::mapToResponse)
                .toList();
    }

    // READ BY ID
    public VoterResponse getVoterById(Long id) {

        Voter voter = voterRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Voter not found"));

        return mapToResponse(voter);
    }

    // UPDATE
    public VoterResponse updateVoter(Long id, VoterRequest request) {

        Voter voter = voterRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Voter not found"));

        voter.setStudentId(request.getStudentId());
        voter.setFullName(request.getFullName());
        voter.setDepartment(request.getDepartment());
        voter.setFaculty(request.getFaculty());

        if (request.getUserId() != null) {
            User user = userRepository.findById(request.getUserId())
                    .orElseThrow(() -> new RuntimeException("User not found"));
            voter.setUser(user);
        }

        Voter updated = voterRepository.save(voter);

        return mapToResponse(updated);
    }

    // DELETE
    public void deleteVoter(Long id) {

        Voter voter = voterRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Voter not found"));

        voterRepository.delete(voter);
    }

    // MAPPER
    private VoterResponse mapToResponse(Voter voter) {

        return VoterResponse.builder()
                .id(voter.getId())
                .studentId(voter.getStudentId())
                .fullName(voter.getFullName())
                .department(voter.getDepartment())
                .faculty(voter.getFaculty())
                .accountActivated(voter.isAccountActivated())
                .hasVoted(voter.isHasVoted())
                .userId(voter.getUser() != null ? voter.getUser().getId() : null)
                .build();
    }
}