package com.just.votingsystem.enums;
//Waxay kaydiyaan qiimayaal go'an (fixed values).
public enum ElectionStatus {
    UPCOMING,
    OPEN,
    CLOSED
}