package com.just.votingsystem.entity;
import jakarta.validation.constraints.NotBlank;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.*;
@Entity
@Table(name = "voters")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Voter {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank(message = "Student ID is required")
    @Column(nullable = false, unique = true)
    private String studentId;

    @NotBlank(message = "Full name is required")
    @Column(nullable = false)
    private String fullName;

    @NotBlank(message = "Department is required")
    @Column(nullable = false)
    private String department;

    @NotBlank(message = "Faculty is required")
    @Column(nullable = false)
    private String faculty;

    @Builder.Default
    @Column(nullable = false)
    private boolean accountActivated = false;

    @Builder.Default
    @Column(nullable = false)
    private boolean hasVoted = false;

    @OneToOne
    @JoinColumn(name = "user_id", unique = true)
    //    user_id wuxuu tilmaamayaa User-ka leh voter-ka
    private User user;

    @OneToOne(mappedBy = "voter")
    @JsonIgnore
    private Candidate candidate;
}