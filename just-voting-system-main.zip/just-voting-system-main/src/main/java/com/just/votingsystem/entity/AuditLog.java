package com.just.votingsystem.entity;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDateTime;

@Entity
@Table(name = "audit_logs")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class AuditLog {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String action;  // Waxay sheegaysaa waxa dhacay, tusaale, loging system

    @Column(length = 1000)
    private String description; // Faahfaahin dheeraad ah., Ahmed voted for Candidate Ali

    @ManyToOne
    @JoinColumn(name = "user_id")
    private User user; // Hal User wuxuu sameyn karaa ficillo badan, login,vote and logOut

    @Column(nullable = false, updatable = false)
    private LocalDateTime createdAt;

    @PrePersist
    public void prePersist() {
        createdAt = LocalDateTime.now();
    }
}