package com.just.votingsystem.repository;

import com.just.votingsystem.entity.Candidate;
import com.just.votingsystem.entity.Election;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface CandidateRepository extends JpaRepository<Candidate, Long> {

    List<Candidate> findByElection(Election election);
}