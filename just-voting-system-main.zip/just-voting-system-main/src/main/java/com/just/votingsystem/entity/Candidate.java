package com.just.votingsystem.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import lombok.*;

@Entity
@Table(name = "candidates")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Candidate {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank(message = "Manifesto is required")
    @Column(nullable = false, length = 2000)
    private String manifesto;

    @NotBlank(message = "Slogan is required")
    @Column(nullable = false, length = 255)
    private String slogan;

    @Column(length = 500)
    private String photoUrl;

    @Builder.Default
    @Column(nullable = false)
    private boolean active = true;  // Musharrax ayaa ka haray tartanka, Ma rabno inaan tirtirno record-kiisa database-ka, Waxaan sameyn karnaa:candidate.setActive(false);

    @OneToOne //Candidate waa ↓ Voter
    @JoinColumn(name = "voter_id", nullable = false, unique = true)
    private Voter voter;

    @ManyToOne // Waxay ka dhigan tahay: Candidate ↓ Election: Candidates badan ayaa ku jira hal Election

    @JoinColumn(name = "election_id", nullable = false)
    private Election election;
}