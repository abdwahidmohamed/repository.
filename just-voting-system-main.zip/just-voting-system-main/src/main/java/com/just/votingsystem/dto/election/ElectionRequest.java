package com.just.votingsystem.dto.election;

import com.just.votingsystem.enums.ElectionStatus;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.*;

import java.time.LocalDateTime;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ElectionRequest {

    @NotBlank(message = "Election title is required")
    private String title;

    private String description;

    @NotNull(message = "Start date is required")
    private LocalDateTime startDate;

    @NotNull(message = "End date is required")
    private LocalDateTime endDate;

    @NotNull(message = "Election status is required")
    private ElectionStatus status;

    private boolean published;

    private Integer maxVotesPerVoter;

    private boolean resultsPublished;
}