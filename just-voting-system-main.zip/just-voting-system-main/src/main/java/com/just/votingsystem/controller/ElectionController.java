package com.just.votingsystem.controller;

import java.util.List;
import org.springframework.web.bind.annotation.GetMapping;

import com.just.votingsystem.dto.election.ElectionRequest;
import com.just.votingsystem.dto.election.ElectionResponse;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import com.just.votingsystem.dto.common.ApiResponse;
import org.springframework.http.ResponseEntity;
import java.util.Map;

import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.PathVariable;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.DeleteMapping;
import com.just.votingsystem.service.ElectionService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/elections")
@RequiredArgsConstructor
public class ElectionController {

    private final ElectionService electionService;

    @GetMapping
    public ResponseEntity<ApiResponse<List<ElectionResponse>>> getAllElections() {

        List<ElectionResponse> response = electionService.getAllElections();

        return ResponseEntity.ok(
                new ApiResponse<>(
                        "Elections retrieved successfully.",
                        response
                )
        );
    }


    @PostMapping
    public ResponseEntity<ApiResponse<ElectionResponse>> createElection(
            @Valid @RequestBody ElectionRequest request) {

        ElectionResponse response = electionService.createElection(request);

        return ResponseEntity.status(HttpStatus.CREATED)
                .body(new ApiResponse<>(
                        "Election created successfully.",
                        response
                ));
    }


    @GetMapping("/{id}")
    public ResponseEntity<?> getElectionById(@PathVariable Long id) {

        ElectionResponse response = electionService.getElectionById(id);

        return ResponseEntity.ok(
                Map.of(
                        "message", "Election retrieved successfully.",
                        "data", response
                )
        );
    }


    @PutMapping("/{id}")
    public ResponseEntity<ApiResponse<ElectionResponse>> updateElection(
            @PathVariable Long id,
            @Valid @RequestBody ElectionRequest request) {

        ElectionResponse response = electionService.updateElection(id, request);

        return ResponseEntity.ok(
                new ApiResponse<>(
                        "Election updated successfully.",
                        response
                )
        );
    }


    @DeleteMapping("/{id}")
    public ResponseEntity<ApiResponse<Void>> deleteElection(
            @PathVariable Long id) {

        electionService.deleteElection(id);

        return ResponseEntity.ok(
                new ApiResponse<>(
                        "Election deleted successfully.",
                        null
                )
        );
    }



}