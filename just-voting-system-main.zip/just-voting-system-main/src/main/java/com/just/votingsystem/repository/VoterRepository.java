package com.just.votingsystem.repository;

import com.just.votingsystem.entity.Voter;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface VoterRepository extends JpaRepository<Voter, Long> {

    Optional<Voter> findByStudentId(String studentId);

    boolean existsByStudentId(String studentId);

}