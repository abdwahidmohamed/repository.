package com.just.votingsystem.security;

public class JwtAuthenticationEntryPoint {
}
