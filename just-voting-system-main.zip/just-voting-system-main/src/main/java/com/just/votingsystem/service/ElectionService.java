package com.just.votingsystem.service;

import com.just.votingsystem.dto.election.ElectionRequest;
import com.just.votingsystem.dto.election.ElectionResponse;
import com.just.votingsystem.entity.Election;

import java.util.List;
import java.util.stream.Collectors;
import com.just.votingsystem.exception.ElectionNotFoundException;
import com.just.votingsystem.repository.ElectionRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class ElectionService {
    private final ElectionRepository electionRepository;

    public ElectionResponse createElection(ElectionRequest request) {

        Election election = Election.builder()
                .title(request.getTitle())
                .description(request.getDescription())
                .startDate(request.getStartDate())
                .endDate(request.getEndDate())
                .status(request.getStatus())
                .published(request.isPublished())
                .maxVotesPerVoter(request.getMaxVotesPerVoter())
                .resultsPublished(request.isResultsPublished())
                .build();

        Election savedElection = electionRepository.save(election);

        return ElectionResponse.builder()
                .id(savedElection.getId())
                .title(savedElection.getTitle())
                .description(savedElection.getDescription())
                .startDate(savedElection.getStartDate())
                .endDate(savedElection.getEndDate())
                .status(savedElection.getStatus())
                .published(savedElection.isPublished())
                .maxVotesPerVoter(savedElection.getMaxVotesPerVoter())
                .resultsPublished(savedElection.isResultsPublished())
                .createdAt(savedElection.getCreatedAt())
                .build();
    }

    public List<ElectionResponse> getAllElections() {

        return electionRepository.findAll()
                .stream()
                .map(election -> ElectionResponse.builder()
                        .id(election.getId())
                        .title(election.getTitle())
                        .description(election.getDescription())
                        .startDate(election.getStartDate())
                        .endDate(election.getEndDate())
                        .status(election.getStatus())
                        .published(election.isPublished())
                        .maxVotesPerVoter(election.getMaxVotesPerVoter())
                        .resultsPublished(election.isResultsPublished())
                        .createdAt(election.getCreatedAt())
                        .build())
                .collect(Collectors.toList());
    }

    public ElectionResponse getElectionById(Long id) {

        Election election = electionRepository.findById(id)
                .orElseThrow(() ->
                        new ElectionNotFoundException("Election not found with id: " + id)
                );

        return ElectionResponse.builder()
                .id(election.getId())
                .title(election.getTitle())
                .description(election.getDescription())
                .startDate(election.getStartDate())
                .endDate(election.getEndDate())
                .status(election.getStatus())
                .published(election.isPublished())
                .maxVotesPerVoter(election.getMaxVotesPerVoter())
                .resultsPublished(election.isResultsPublished())
                .createdAt(election.getCreatedAt())
                .build();
    }

    public ElectionResponse updateElection(Long id, ElectionRequest request) {

        Election election = electionRepository.findById(id)
                .orElseThrow(() ->
                        new ElectionNotFoundException("Election not found with id: " + id)
                );

        election.setTitle(request.getTitle());
        election.setDescription(request.getDescription());
        election.setStartDate(request.getStartDate());
        election.setEndDate(request.getEndDate());
        election.setStatus(request.getStatus());
        election.setPublished(request.isPublished());
        election.setMaxVotesPerVoter(request.getMaxVotesPerVoter());
        election.setResultsPublished(request.isResultsPublished());

        Election updatedElection = electionRepository.save(election);

        return ElectionResponse.builder()
                .id(updatedElection.getId())
                .title(updatedElection.getTitle())
                .description(updatedElection.getDescription())
                .startDate(updatedElection.getStartDate())
                .endDate(updatedElection.getEndDate())
                .status(updatedElection.getStatus())
                .published(updatedElection.isPublished())
                .maxVotesPerVoter(updatedElection.getMaxVotesPerVoter())
                .resultsPublished(updatedElection.isResultsPublished())
                .createdAt(updatedElection.getCreatedAt())
                .build();
    }


    public void deleteElection(Long id) {

        Election election = electionRepository.findById(id)
                .orElseThrow(() ->
                        new ElectionNotFoundException("Election not found with id: " + id)
                );

        electionRepository.delete(election);
    }






}