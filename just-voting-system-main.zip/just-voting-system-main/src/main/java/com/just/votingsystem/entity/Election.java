package com.just.votingsystem.entity;

import com.just.votingsystem.enums.ElectionStatus;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import lombok.*;

import java.time.LocalDateTime;

@Entity
@Table(name = "elections")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Election {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank(message = "Election title is required")
    @Column(nullable = false)
    private String title;

    @Column(length = 1000)
    private String description;

    @Column(nullable = false)
    private LocalDateTime startDate;

    @Column(nullable = false)
    private LocalDateTime endDate;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private ElectionStatus status;

    @Builder.Default
    @Column(nullable = false)
    private boolean published = false; // Admin ayaa diyaarin kara election-ka isagoo aan weli ardayda tusin

    @Builder.Default
    @Column(nullable = false)
    private Integer maxVotesPerVoter = 1; //Qof walba wuxuu dooran karaa hal musharrax, lknsa mustaqbal ka waa labadali akraa tirada codadka

    @Builder.Default
    @Column(nullable = false)
    private boolean resultsPublished = false; //Doorashadu way dhammaan kartaa (CLOSED), laakiin natiijada lama soo bandhigayo ilaa Admin-ku oggolaado.

    @Column(nullable = false, updatable = false)
    private LocalDateTime createdAt;

    @PrePersist
    public void prePersist() {
        createdAt = LocalDateTime.now();
    }
}