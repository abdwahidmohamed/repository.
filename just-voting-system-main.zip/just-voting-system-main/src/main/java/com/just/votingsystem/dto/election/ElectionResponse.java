package com.just.votingsystem.dto.election;

import com.just.votingsystem.enums.ElectionStatus;
import lombok.*;

import java.time.LocalDateTime;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ElectionResponse {

    private Long id;

    private String title;

    private String description;

    private LocalDateTime startDate;

    private LocalDateTime endDate;

    private ElectionStatus status;

    private boolean published;

    private Integer maxVotesPerVoter;

    private boolean resultsPublished;

    private LocalDateTime createdAt;
}