package com.just.votingsystem.repository;

import com.just.votingsystem.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface UserRepository extends JpaRepository<User, Long> {

    Optional<User> findByEmail(String email); // Waxay soo raadisaa user email-kiisa
    // → Waxay hubisaa haddii email-ka hore u jiro.

    boolean existsByEmail(String email);
}