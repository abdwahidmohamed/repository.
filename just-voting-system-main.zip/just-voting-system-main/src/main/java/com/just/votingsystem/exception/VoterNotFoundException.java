package com.just.votingsystem.exception;

public class VoterNotFoundException extends RuntimeException {

    public VoterNotFoundException(String message) {
        super(message);
    }
}
