package com.just.votingsystem.enums;

public enum Role {
    ADMIN,
    USER
}