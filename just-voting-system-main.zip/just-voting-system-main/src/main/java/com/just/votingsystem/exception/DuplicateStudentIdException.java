package com.just.votingsystem.exception;

public class DuplicateStudentIdException extends RuntimeException {

    public DuplicateStudentIdException(String message) {
        super(message);
    }
}