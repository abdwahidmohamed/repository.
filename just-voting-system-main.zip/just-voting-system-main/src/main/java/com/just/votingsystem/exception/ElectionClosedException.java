package com.just.votingsystem.exception;

public class ElectionClosedException extends RuntimeException {

    public ElectionClosedException(String message) {
        super(message);
    }
}