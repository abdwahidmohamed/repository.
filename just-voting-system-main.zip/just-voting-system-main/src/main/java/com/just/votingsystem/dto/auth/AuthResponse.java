package com.just.votingsystem.dto.auth;

import com.just.votingsystem.enums.Role;
import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class AuthResponse {

    private String token;
    private String email;
    private Role role;
}